package net.sf.morph.transform.copiers.dsl;

/**
 *
 */
public class ShortLeftwardDSLDefinedCopierTest extends LeftwardDSLDefinedCopierTest {

	/* (non-Javadoc)
	 * @see net.sf.morph.transform.copiers.dsl.DSLDefinedCopierTestBase#getSource()
	 */
	protected String getSource() {
		return "shortLeftwardTest.morph";
	}
}
