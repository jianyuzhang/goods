package net.sf.morph.transform.copiers.dsl;

/**
 *
 */
public class ShortRightwardDSLDefinedCopierTest extends RightwardDSLDefinedCopierTest {

	/* (non-Javadoc)
	 * @see net.sf.morph.transform.copiers.dsl.DSLDefinedCopierTestBase#getSource()
	 */
	protected String getSource() {
		return "shortRightwardTest.morph";
	}
}
