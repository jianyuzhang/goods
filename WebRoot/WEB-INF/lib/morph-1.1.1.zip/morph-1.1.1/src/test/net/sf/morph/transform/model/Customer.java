/**
 * 
 */
package net.sf.morph.transform.model;


public interface Customer extends Person {
	public String getCustomerNumber();
	public void setCustomerNumber(String customerNumber);
}