package net.sf.morph.transform.model;

public interface LineItem {
	void setQuantity(int quantity);
	int getQuantity();
	void setItemId(String itemId);
	String getItemId();
}
