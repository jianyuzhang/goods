/**
 * 
 */
package net.sf.morph.transform.model;


public interface Address {
	public Person getPerson();
	public void setPerson(Person person);
	public String getText();
	public void setText(String text);
}